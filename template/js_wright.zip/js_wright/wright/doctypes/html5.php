<?php

require_once('default.php');

class HtmlAdapterHtml5 extends HtmlAdapterAbstract
{

}