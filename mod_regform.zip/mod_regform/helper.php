<?php
defined('_JEXEC') or die('Direct Access to this location is not allowed.');
 
class ModRegformHelper
{
    /**
     * Returns a list of post items
    */
    private $results = null;
    private $resultsObj = null;

}