<?php
defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.view');

JToolBarHelper::title('Holiness Page');
?>

<h1>Holiness Page</h1>
